//============================================================================
// Name        : CourseMenu.cpp
// Author      : Chayne Pieri
// Version     : 1.0
// Copyright   : Copyright � 2017 SNHU COCE
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

//============================================================================
// Global definitions visible to all methods and classes
//============================================================================

// Define a structure to hold course information
struct Course {

	string courseNumber;
	string name;
	vector<string> prerequisites;

};

/**
*  Split inputs into tokens.If no delimiter given, use space as delimiter.
*/
vector<string> tokenize(string data, string delimiter = " ") {

	// Declarations
	vector<string> vectorList;
	int start = 0;
	int end = data.find(delimiter);

	while (end != -1) {

		// Take next data, place at back of array
		vectorList.push_back(data.substr(start, end - start));
		start = end + delimiter.size();
		end = data.find(delimiter, start);

	}

	// Take last item, place at end of array
	vectorList.push_back(data.substr(start, end - start));

	// Return vector array of items from data
	return vectorList;

}


/**
 *  Load file, take in course information into list.
 */
vector<Course> LoadDataStructure() {
	
	// Input file stream for course info.
	ifstream fin("abcu.txt", ios::in);

	// Declarations
	vector<Course> courses;
	string line;

	// If more data in file, add course and its information
	while (fin.peek() != EOF) {

		// Get new line for next loop.
		getline(fin, line);


		// Create course for line information
		Course course;

		// Tokenize course data.
		vector<string> courseData = tokenize(line, ",");

		// Set required course info from first 2 indices.
		course.courseNumber = courseData[0];
		course.name = courseData[1];

		// Set any prerequisites (anything greater than 2)
		for (unsigned int i = 2; i < courseData.size(); i++) {

			course.prerequisites.push_back(courseData[i]);

		}


		// Add to back of courses list.
		courses.push_back(course);

	}


	// Close text file
	fin.close();

	// Print success prompt.
	cout << "Courses now loaded." << endl;

	// Return courses list
	return courses;

}

/**
*  Print individual course's information.
*/
void printCourse(Course course) {

	// Gather course information in preparation of printing.
	string courseNumber = course.courseNumber;
	string name = course.name;
	vector<string> prerequisites = course.prerequisites;

	// Print according to format necessary.
	cout << courseNumber << ", " << name << endl;

}

/**
*  Print full course list information.
*/
void printCourseList(vector<Course> courses) {

	// Get course list size.
	int coursesSize = courses.size();

	// Sort the courses list.
	for (int i = 0; i < coursesSize - 1; i++) {

		for (int j = 0; j < coursesSize - i - 1; j++) {

			// Sorting by courseNumber.
			if (courses[j].courseNumber > courses[j + 1].courseNumber) {

				swap(courses[j + 1], courses[j]);

			}
		}
	}

	// Prompt
	cout << "Here is a sample schedule:" << endl << endl;

	// Print all course information using printCourse function.
	for (int i = 0; i < coursesSize; i++) {

		printCourse(courses[i]);

	}
}

/**
*  Search courses list based on user input
*/
void searchCourse(vector<Course> courses) {

	// Declarations
	int coursesSize = courses.size();
	string userInput;
	string courseNumber;
	bool courseFound = false;
	vector<string> prerequisites;

	// Gather user input
	cout << "What course do you want to know about? ";
	cin >> userInput;

	// Convert user input to uppercase
	courseNumber = toupper(userInput[0]);

	for (unsigned int i = 1; i < userInput.length(); i++) {
		
		courseNumber.append(1, toupper(userInput[i]));

	}

	// Search course list for specific course number.
	for (int i = 0; i < coursesSize; i++) {

		// If course is found, print it
		if (courses[i].courseNumber == courseNumber) {

			// Boolean flag marked found, print found info, break out of for loop.
			courseFound = true;
			printCourse(courses[i]);

			// Print prerequisites
			prerequisites = courses[i].prerequisites;

			if (prerequisites.size() > 0) {

				cout << "Prerequisites: ";

				for (unsigned int j = 0; j < prerequisites.size(); j++) {

					cout << prerequisites[j];

					if (j < prerequisites.size() - 1) {
						
						cout << ", ";

					}
				}

				cout << endl << endl;

			}

			break;

		}
	}


	// If no course found, print not found
	if (!courseFound) {

		cout << "No matching course found for " << courseNumber << "." << endl << endl;

	}
}

/**
 * The one and only main() method
 */
int main(int argc, char** argv) {

	// Declarations
	vector<Course> courses;
	int choice = 0;

	// Initial prompt
	cout << "Welcome to the course planner." << endl << endl;

	// Loop until exit choice selected.
	while (choice != 9) {

		// Print menu
		cout << "   1. Load Data Structure." << endl;
		cout << "   2. Print Course List." << endl;
		cout << "   3. Print Course." << endl;
		cout << "   9. Exit." << endl << endl;

		// Prompt user to enter choice
		cout << "What would you like to do? ";
		cin >> choice;

		// Switch cases
		switch (choice) {

		case 1:
			courses = LoadDataStructure();
			cout << endl;
			break;

		case 2:
			printCourseList(courses);
			cout << endl;
			break;

		case 3:
			searchCourse(courses);
			cout << endl;
			break;

		case 9:
			// Exit
			break;

		default:
			cout << choice << " is not a valid option." << endl << endl;
			break;

		}
	}

	cout << "Thank you for using the course planner!" << endl;

	system("pause");

	return 0;

}